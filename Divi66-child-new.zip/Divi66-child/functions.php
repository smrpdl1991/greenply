<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if (!function_exists('chld_thm_cfg_locale_css')) :
    function chld_thm_cfg_locale_css($uri)
    {
        if (empty($uri) && is_rtl() && file_exists(get_template_directory() . '/rtl.css'))
            $uri = get_template_directory_uri() . '/rtl.css';
        return $uri;
    }
endif;
add_filter('locale_stylesheet_uri', 'chld_thm_cfg_locale_css');


if (!function_exists('chld_thm_cfg_parent_css')) :
    function chld_thm_cfg_parent_css()
    {
        wp_enqueue_style('chld_thm_cfg_parent', trailingslashit(get_template_directory_uri()) . 'style.css', array());
        wp_enqueue_script('customjs', get_stylesheet_directory_uri() . '/js/script.js', array('jquery-ui-tabs'), '1.0.0', 'true');
        wp_localize_script('customjs', 'greenplayAjax', array('ajaxurl' => admin_url('admin-ajax.php')));
        wp_enqueue_style('fancybox', 'https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.css', array());
        wp_enqueue_script('fancyboxjs', 'https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js', array(), '4.0', 'true');
    }
endif;
add_action('wp_enqueue_scripts', 'chld_thm_cfg_parent_css', 10);


// END ENQUEUE PARENT ACTION

/**
 * Customize ACF
 */
add_filter('acf/settings/path', 'my_acf_settings_path');
function my_acf_settings_path($path)
{
    $path = get_stylesheet_directory() . '/acf/';
    return $path;
}
add_filter('acf/settings/dir', 'my_acf_settings_dir');
function my_acf_settings_dir($dir)
{
    $dir = get_stylesheet_directory_uri() . '/acf/';
    return $dir;
}
add_filter('acf/settings/show_admin', '__return_true');
include_once(get_stylesheet_directory() . '/acf/acf.php');

if (function_exists('acf_add_options_page')) {
    acf_add_options_page(array(
        'page_title'     => 'Greenplay  Options',
        'menu_title'    => 'Greenplay  Options',
        'menu_slug'     => 'theme-general-settings',
        'capability'    => 'edit_posts',
        'redirect'        => false
    ));
}

include_once(get_stylesheet_directory() . '/inc/cpt.php');
include_once(get_stylesheet_directory() . '/inc/team.php');

/*
 * Add to logs
 */
function greenplay_addToLog($fileName, $data, $datatype)
{
    $current_date = date('Y-m-d');
    $current_time = date('H:i:s');
    $filename = get_stylesheet_directory() . '/logs/' . $fileName . '/' . $current_date . '.log';

    $dirname = dirname($filename);
    if (!is_dir($dirname)) {
        mkdir($dirname, 0755, true);
    }
    $fp = fopen($filename, 'a'); //opens file in append mode
    $content = "[" . $current_date . ' ' . $current_time . "] " . json_encode($data) . " - " . $datatype . "\n";
    fwrite($fp, $content);
    fclose($fp);
}

function mpdn_show_on_account($user)
{
    $sexe = [
        'femme' => 'Femme',
        'homme' => 'Homme',
        'autre' => 'Autre'
    ];
    $positions = [
        'avant-tribord' => 'Avant tribord',
        'avant-babord' => 'Avant babord',
        'arriere-tribord' => 'Arrière tribord',
        'arriere-babord' => 'Arrière babord',
        'barreur' => 'Barreur',
    ];
    $mepr_sexe = get_user_meta($user->ID, 'mepr_sexe', true);
    $mepr_telephone = get_user_meta($user->ID, 'mepr_telephone', true);
    $ice_canoe = get_user_meta($user->ID, 'mepr_first_year_of_ice_canoe', true);
    $getPosition = get_user_meta($user->ID, 'mepr_position', true);
    $leader = get_user_meta($user->ID, 'mepr_responsable_de_lequipe', true);
    $captain = get_user_meta($user->ID, 'mepr_capitaine_de_lequipe', true);

    $teams = [];
    $args = array(
        'post_type' => 'teams',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'orderby' => 'title',
        'order' => 'ASC'
    );
    $teams_query = new WP_Query($args);
    if ($teams_query->have_posts()) {
        while ($teams_query->have_posts()) {
            $teams_query->the_post();
            $teams[get_the_ID()] = get_the_title();
        }
    }
    wp_reset_postdata();
    $getTeam = get_user_meta($user->ID, 'associate_team', true);
?>
    <div class="mp-form-row">
        <div class="mp-form-label">
            <label>Sex</label>
        </div>

        <select name="mepr_sexe" id="mepr_sexe">
            <option value="">Choose Gender</option>
            <?php
            foreach ($sexe as $sex => $label) { ?>
                <option <?php echo $sex == $mepr_sexe ? "selected" : ""; ?> value=<?php echo $sex; ?>><?php echo $label; ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="mp-form-row">
        <div class="mp-form-label">
            <label>Phone</label>
        </div>
        <input type="tel" name="mepr_telephone" id="mepr_telephone" class="mepr-form-input mepr-telephone" value="<?php echo $mepr_telephone; ?>" />
    </div>
    <div class="mp-form-row">
        <div class="mp-form-label">
            <label>First year of ice canoe</label>
        </div>
        <input type="tel" name="mepr_first_year_of_ice_canoe" id="mepr_first_year_of_ice_canoe" class="mepr-form-input mepr-telephone" value="<?php echo $ice_canoe; ?>" />
    </div>
    <div class="mp-form-row">
        <div class="mp-form-label">
            <label>Team</label>
        </div>

        <select name="mepr_sexe" id="mepr_sexe">
            <option value="">Choose Team</option>
            <?php
            foreach ($teams as $team => $label) { ?>
                <option <?php echo $team == $getTeam ? "selected" : ""; ?> value=<?php echo $team; ?>><?php echo $label; ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="mp-form-row">
        <div class="mp-form-label">
            <label>Position</label>
        </div>

        <select name="mepr_sexe" id="mepr_sexe">
            <option value="">Choose Position</option>
            <?php
            foreach ($positions as $position => $label) { ?>
                <option <?php echo $position == $getPosition ? "selected" : ""; ?> value=<?php echo $position; ?>><?php echo $label; ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="mp-form-row mepr_custom_field mepr_mepr_responsable_de_lequipe">
        <?php $checked = $leader ? 'checked="checked"' : ""; ?>
        <label for="mepr_responsable_de_lequipe" class="mepr-checkbox-field mepr-form-input ">
            <input type="checkbox" name="mepr_responsable_de_lequipe" id="mepr_responsable_de_lequipe" <?php echo $checked; ?>>
            <?php echo _e('Leader', 'memberpress'); ?>
        </label>
    </div>
    <div class="mp-form-row mepr_custom_field mepr_capitaine_de_lequipe">
        <?php $checkedCaptain = $captain ? 'checked="checked"' : ""; ?>
        <label for="mepr_capitaine_de_lequipe" class="mepr-checkbox-field mepr-form-input ">
            <input type="checkbox" name="mepr_capitaine_de_lequipe" id="mepr_capitaine_de_lequipe" <?php echo $checkedCaptain; ?>>
            <?php echo _e('Captain', 'memberpress'); ?>
        </label>
    </div>
<?php
}
add_action('mepr-account-home-fields', 'mpdn_show_on_account', 10);
