<?php
/*
* Creating a function to create our CPT
*/

function custom_post_type()
{
    $customPostTypes = [
        'teams' => [
            'name' => 'teams',
            'singular_name' => 'Team',
            'plural_name' => 'Teams',
            'slug' => 'teams',
        ],
        'trainings' => [
            'name' => 'Trainings',
            'singular_name' => 'Training',
            'plural_name' => 'Trainings',
            'slug' => 'trainings',
        ],
    ];

    foreach ($customPostTypes as $postType) {
        register_post_type($postType['name'], [
            'labels' => [
                'name' => $postType['plural_name'],
                'singular_name' => $postType['singular_name'],
                'add_new' => 'Add New',
                'add_new_item' => 'Add New ' . $postType['singular_name'],
                'edit' => 'Edit',
                'edit_item' => 'Edit ' . $postType['singular_name'],
                'new_item' => 'New ' . $postType['singular_name'],
                'view' => 'View ' . $postType['singular_name'],
                'view_item' => 'View ' . $postType['singular_name'],
                'search_items' => 'Search ' . $postType['plural_name'],
                'not_found' => 'No ' . $postType['plural_name'] . ' found',
                'not_found_in_trash' => 'No ' . $postType['plural_name'] . ' found in Trash',
                'parent' => 'Parent ' . $postType['singular_name'],
            ],
            'public' => true,
            'has_archive' => true,
            'rewrite' => [
                'slug' => $postType['slug'],
            ],
            'supports' => [
                'title',
                'editor',
                'excerpt',
                'thumbnail',
                'revisions',
                'page-attributes',
                'post-formats',
            ],
        ]);
    }
}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not 
* unnecessarily executed. 
*/

add_action('init', 'custom_post_type', 0);
