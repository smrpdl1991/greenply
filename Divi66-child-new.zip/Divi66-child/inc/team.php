<?php

/**
 * Also assign the selected team to their profile
 */
add_action('save_post', 'updateTeamMemberDetail');
function updateTeamMemberDetail($post_id)
{
    // get post type
    $post_type = get_post_type($post_id);

    // return if not a team post
    if ($post_type != 'teams') {
        return;
    }

    // If this is a revision, get real post ID
    if ($parent_id = wp_is_post_revision($post_id))
        $post_id = $parent_id;

    // get selected team members
    $team_members = get_field('team_members', $post_id);

    // loop through team members and assign them to the profile
    if ($team_members) {
        foreach ($team_members as $team_member) {
            update_field('field_62db7e76b55c6', $post_id, 'user_' . $team_member);
        }
    }

    // get team captain
    $team_captain = get_field('team_captain', $post_id);

    // get team leader
    $team_leader = get_field('team_leader', $post_id);
}

//sorting according to category for search page
add_action('wp_ajax_greenplay_delete_team', 'greenplay_delete_team'); // wp_ajax_{ACTION HERE} 
add_action('wp_ajax_nopriv_greenplay_delete_team', 'greenplay_delete_team');
function greenplay_delete_team()
{

    greenplay_addToLog('team', $_POST, 'teams');
    $current_user = wp_get_current_user();

    $team_id = $_POST['team_id'];

    // return if not a team id
    if (!$team_id) {
        return wp_send_json_error('No team id');
    }

    // delete team
    update_user_meta($team_id, 'associate_team', ""); //update to associate team

    // return success
    wp_send_json_success('Team deleted');
}

add_action('wp_ajax_greenplay_create_team', 'greenplay_create_team'); // wp_ajax_{ACTION HERE} 
add_action('wp_ajax_nopriv_greenplay_create_team', 'greenplay_create_team');
function greenplay_create_team()
{
    // validation
    if (!isset($_POST['team_name']) || !isset($_POST['team_class']) || !isset($_POST['canoe_number'])) {
        return wp_send_json_error('Missing required fields');
        die();
    }

    $post_title = $_POST['team_name'];
    $current_user = wp_get_current_user();


    // check if team_id already exists in $_POST
    if (isset($_POST['team_id'])) {
        $post_id = $_POST['team_id'];
    } else {
        // check if team name already exists
        $team_name_exists = get_page_by_title($post_title, OBJECT, 'teams');
        greenplay_addToLog('team', $team_name_exists, 'files');
        if ($team_name_exists->post_status == 'publish') {
            return wp_send_json_error('Team name already exists');
            die();
        }

        // create if team does not exist
        $new_post = array(
            'post_title' => $post_title,
            'post_status' => 'publish',
            'post_type' => 'teams'
        );

        $post_id = wp_insert_post($new_post);
    }

    // list of 10 canoe numbers
    $canoeList = [
        'Canoer 1',
        'Canoer 2',
        'Canoer 3',
        'Canoer 4',
        'Canoer 5',
        'Canoer 6',
        'Canoer 7',
        'Canoer 8',
        'Canoer 9',
        'Canoer 10'
    ];
    update_field('field_62e009522da8f', $canoeList, $post_id); //update to canoe_list

    update_user_meta($current_user->ID, 'associate_team', $post_id); //update to associate team

    //update class
    update_field('field_62dada08db34e', $_POST['team_class'], $post_id); // team_class
    update_field('field_62dada55db34f', $_POST['canoe_number'], $post_id); // no of canoe_number

    // add team captain
    $team_captain = $current_user->ID;
    update_field('field_62dfa5d6a9569', $team_captain, $post_id);

    // add team leader
    $team_leader = $current_user->ID;
    update_field('field_62dfa5bba9568', $team_leader, $post_id); //update to team leader

    // add team members
    $team_members = [$current_user->ID];
    if ($team_members && $post_id) {
        update_field('field_62dadace72fee', $team_members, $post_id);
    }

    if (!function_exists('wp_generate_attachment_metadata')) {
        require_once(ABSPATH . "wp-admin" . '/includes/image.php');
        require_once(ABSPATH . "wp-admin" . '/includes/file.php');
        require_once(ABSPATH . "wp-admin" . '/includes/media.php');
    }
    if ($_FILES) {
        foreach ($_FILES as $file => $array) {
            if ($_FILES[$file]['error'] !== UPLOAD_ERR_OK) {
                return "upload error : " . $_FILES[$file]['error'];
            }
            $attach_id = media_handle_upload($file, $post_id);
        }
    }
    if ($attach_id > 0) {
        //and if you want to set that image as Post then use:
        update_post_meta($post_id, '_thumbnail_id', $attach_id);
        update_post_meta($post_id, '_thumbnail_id', $attach_id);
    }

    return wp_send_json_success($_POST['team_id'] ? 'Team Updated Successfully' : 'Team created successfully');
    die();
}

function change_role_name()
{
    global $wp_roles;

    $roles = [
        [
            'name' => 'team_leader',
            'display_name' => 'Team Leader',
        ],
        [
            'name' => 'trainers',
            'display_name' => 'Trainers'
        ],
        [
            'name' => 'promoters',
            'display_name' => 'Promoters'
        ]
    ];

    if (!isset($wp_roles)) {
        $wp_roles = new WP_Roles();
    }

    // Change the name of the subscriber role to member
    $wp_roles->roles['subscriber']['name'] = 'Member';
    // $wp_roles->roles['administrator']['name'] = 'Admin';

    // foreach ($roles as $role) {
    //     $wp_roles->add_role($role['name'], $role['display_name']);
    // }
}
// add_action('init', 'change_role_name');


add_action('after_setup_theme', 'greenplay_customer_functions');
function greenplay_customer_functions()
{
    if (!current_user_can('administrator') && !is_admin()) {
        show_admin_bar(false);
    }
}


add_action('wp_ajax_greenplay_update_profile', 'greenplay_update_profile'); // wp_ajax_{ACTION HERE} 
add_action('wp_ajax_nopriv_greenplay_update_profile', 'greenplay_update_profile');
function greenplay_update_profile()
{
    if ($_POST['action'] != 'greenplay_update_profile') {
        return "Failed";
    }

    $current_user = wp_get_current_user();
    $userId = $current_user->ID;

    // update first name
    if ($_POST['first-name'] != '') {
        update_user_meta($userId, 'first_name', $_POST['first-name']);
    }

    // update last name
    if ($_POST['last-name'] != '') {
        update_user_meta($userId, 'last_name', $_POST['last-name']);
    }

    // update sex
    if ($_POST['sex'] != '') {
        update_user_meta($userId, 'mepr_sexe', $_POST['sex']);
    }

    // update city
    if ($_POST['city'] != '') {
        update_user_meta($userId, 'mepr-address-city', $_POST['city']);
    }

    // update phone
    if ($_POST['phone'] != '') {
        update_user_meta($userId, 'mepr_telephone', $_POST['phone']);
    }

    // update ice_canoe
    if ($_POST['ice_canoe'] != '') {
        update_user_meta($userId, 'mepr_first_year_of_ice_canoe', $_POST['ice_canoe']);
    }

    // update email
    if ($_POST['email'] != '') {
        update_user_meta($userId, 'email', $_POST['email']);
    }

    // update team
    if ($_POST['associate_team'] != '') {
        update_user_meta($userId, 'associate_team', $_POST['associate_team']);

        // get all team members
        $team_members = get_field('field_62dadace72fee', $_POST['associate_team']);
        if ($team_members) {
            $team_members[] = $userId;
            update_field('field_62dadace72fee', $team_members, $_POST['associate_team']);
        } else {
            $team_members = [$userId];
            update_field('field_62dadace72fee', $team_members, $_POST['associate_team']);
        }
    }

    // update position
    if ($_POST['position'] != '') {
        update_user_meta($userId, 'position', $_POST['position']);
    }

    // update leader
    if ($_POST['mepr_responsable_de_lequipe'] != '') {
        update_user_meta($userId, 'mepr_responsable_de_lequipe', $_POST['mepr_responsable_de_lequipe']);
    } else {
        update_user_meta($userId, 'mepr_responsable_de_lequipe', "");
    }

    // update captain
    if ($_POST['mepr_capitaine_de_lequipe'] != '') {
        update_user_meta($userId, 'mepr_capitaine_de_lequipe', $_POST['mepr_capitaine_de_lequipe']);
    } else {
        update_user_meta($userId, 'mepr_capitaine_de_lequipe', "");
    }

    return 'success';
    die();
}


function getAllTeams()
{
    $args = array(
        'post_type' => 'teams',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'orderby' => 'title',
        'order' => 'ASC'
    );
    $teams = get_posts($args);
    $json = json_encode($teams); ?>

    <script type="module">
        var teams = <?php echo $json; ?>;
        let teams_list = [];
        for (let i = 0; i < teams.length; i++) {
            teams_list.push({
                id: teams[i].ID,
                title: teams[i].post_title
            });
        }

        // add teams to the select element
        let teams_select = document.getElementById('mepr_equipe1');
        for (let i = 0; i < teams_list.length; i++) {
            let option = document.createElement('option');
            option.value = teams_list[i].id;
            option.innerHTML = teams_list[i].title;
            teams_select.append(option);
        }

        // append the sexe select element to the form
        let sexe_select = document.createElement('select');

        console.log(teams_select);
    </script>

<?php
    return $teams;
}
// getAllTeams();


add_action('wp_ajax_file_upload', 'file_upload_callback');
add_action('wp_ajax_nopriv_file_upload', 'file_upload_callback');
function file_upload_callback()
{
    check_ajax_referer('file_upload', 'security');
    $arr_img_ext = array('image/png', 'image/jpeg', 'image/jpg', 'image/gif');
    if (in_array($_FILES['file']['type'], $arr_img_ext)) {
        $upload = wp_upload_bits($_FILES["file"]["name"], null, file_get_contents($_FILES["file"]["tmp_name"]));
        //$upload['url'] will gives you uploaded file path
    }
    wp_die();
}

// get all users related to a team
function get_team_members($associate_team)
{

    // return if no team is selected
    if ($associate_team == '') {
        return;
    }

    $args = array(
        'order'          => 'ASC',
        'orderby'        => 'display_name',
        'count_total'    => true,
        'meta_key'       => 'associate_team',
        'meta_value'     => $associate_team,
        'meta_compare '  => 'LIKE'
    );

    // The User Query
    $user_query = new WP_User_Query($args);

    return $user_query->results ? $user_query->results : [];
}
