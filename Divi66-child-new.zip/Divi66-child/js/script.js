jQuery('.tab-area .tabs .tab').removeClass('active');
jQuery('.tab-area .tabs .tab:first-child').addClass('active');
jQuery('.tab-area .tab-content:first-child').addClass('active');

// on click envent on tab
jQuery('.tab-area .tabs .tab').click(function () {
	jQuery('.tab-area .tabs .tab').removeClass('active');
	jQuery(this).addClass('active');
	var tab_id = jQuery(this).attr('data-tab');
	console.log(tab_id);
	jQuery('.tab-area').find('.tab-content').removeClass('active');
	jQuery('#' + tab_id).addClass('active');
});

jQuery('.profile-tabs .profile-tab:first-child').addClass('active');
jQuery('.profile-content:first-child').addClass('active');
jQuery('.profile-tabs .profile-tab').click(function () {
	jQuery('.profile-tabs .profile-tab').removeClass('active');
	jQuery(this).addClass('active');
	var tab_id = jQuery(this).attr('data-tab');
	console.log(tab_id);
	jQuery('.tab-area').find('.profile-content').removeClass('active');
	jQuery('#' + tab_id).addClass('active');
});

jQuery('#create-team-form').submit(function (e) {
	e.preventDefault();

	let formData = new FormData();

	// get all form data
	let input_serialized = convertFormToJSON($(this));
	input_serialized.action = 'greenplay_create_team';
	jQuery('.message').html('');

	jQuery.ajax({
		url: greenplayAjax.ajaxurl,
		data: input_serialized,
		type: 'post', // POST
		beforeSend: function () {
			jQuery('.is-loading').show();
		},
		complete: function () {
			jQuery('.is-loading').hide();
			console.log('complete');
		},
		success: function (data) {
			const html = `<div class="alert alert-success">${data.data}</div>`;
			jQuery('.message').html(html);
			if (data.success) {
				window.location.reload();
			}
		},
		error: function (data) {
			const html = `<div class="alert alert-error">${data.data}</div>`;
			jQuery('.message').html(html);
		},
	});
});

// for tabs
// $(function () {
// 	$('.tabs').tabs();
// });

function convertFormToJSON(form) {
	const array = $(form).serializeArray(); // Encodes the set of form elements as an array of names and values.
	const json = {};
	$.each(array, function () {
		json[this.name] = this.value || '';
	});
	return json;
}

function onTeamDelete($teamId) {
	jQuery.ajax({
		url: greenplayAjax.ajaxurl,
		data: {
			action: 'greenplay_delete_team',
			team_id: $teamId,
		},
		type: 'post', // POST
		beforeSend: function () {
			jQuery('.is-loading').show();
			jQuery('.team-list').addClass('isLoading');
			console.log('loading');
		},
		complete: function () {
			jQuery('.is-loading').hide();
			console.log('complete');
		},
		success: function (data) {
			// reload page
			const html = `<div class="alert alert-success">${data.data}</div>`;
			jQuery('.message').html(html);
			// console.log(data);
			window.location.reload();
		},
		error: function (data) {
			const html = `<div class="alert alert-error">${data.data}</div>`;
			jQuery('.message').html(html);
			console.log(data);
		},
	});
}

// profile update
jQuery('#update-profile').submit(function (e) {
	e.preventDefault();

	// get all form data
	let input_serialized = convertFormToJSON($(this));
	input_serialized.action = 'greenplay_update_profile';

	// disable submit button
	jQuery('#update-profile button[type="submit"]').attr('disabled', true);

	jQuery.ajax({
		url: greenplayAjax.ajaxurl,
		data: input_serialized,
		type: 'post', // POST
		beforeSend: function () {
			jQuery('.is-loading').show();
		},
		complete: function () {
			jQuery('.is-loading').hide();
			jQuery('#update-profile button[type="submit"]').attr('disabled', false);
		},
		success: function (data) {
			// add message to the top of the page
			// jQuery('.message').html(data);
		},
	});
});

// jQuery(function ($) {
// 	$('body').on('change', '#file', function () {
// 		$this = $(this);
// 		file_data = $(this).prop('files')[0];
// 		form_data = new FormData();
// 		form_data.append('file', file_data);
// 		form_data.append('action', 'file_upload');

// 		$.ajax({
// 			url: greenplayAjax.ajaxurl,
// 			type: 'POST',
// 			contentType: false,
// 			processData: false,
// 			data: form_data,
// 			success: function (response) {
// 				$this.val('');
// 				alert('File uploaded successfully.');
// 			},
// 		});
// 	});
// });

// set to url params
function setParams(name, value) {
	const searchSlug =
		typeof window !== 'undefined' ? window.location.search : '';
	const urlParams = new URLSearchParams(searchSlug);

	urlParams.set(name, value);
	window.history.pushState(
		{},
		'',
		`${window.location.pathname}?${urlParams.toString()}`
	);
}

// delete
function removeParams(name) {
	const searchSlug =
		typeof window !== 'undefined' ? window.location.search : '';
	const urlParams = new URLSearchParams(searchSlug);
	urlParams.delete(name);
	window.history.pushState(
		{},
		'',
		`${window.location.pathname}?${urlParams.toString()}`
	);
}

// get params from url
function getParams(name) {
	const searchSlug =
		typeof window !== 'undefined' ? window.location.search : '';
	const urlParams = new URLSearchParams(searchSlug);
	return urlParams.get(name) || '';
}
