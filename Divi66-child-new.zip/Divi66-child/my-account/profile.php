<?php

// return if user is not logged in
if (!is_user_logged_in()) return;

$profileTabs = [
    'information'   => 'My Information',
    'subscription'  => 'Subscription',
    'payment'       => 'Payment'
];

$sexe = [
    'femme' => 'Femme',
    'homme' => 'Homme',
    'autre' => 'Autre'
];

$positions = [
    'avant-tribord' => 'Avant tribord',
    'avant-babord' => 'Avant babord',
    'arriere-tribord' => 'Arrière tribord',
    'arriere-babord' => 'Arrière babord',
    'barreur' => 'Barreur',
];

$current_user = wp_get_current_user();
$mepr_sexe = get_user_meta($current_user->ID, 'mepr_sexe', true);
$city = get_user_meta($current_user->ID, 'mepr-address-city', true);
$mepr_telephone = get_user_meta($current_user->ID, 'mepr_telephone', true);
$ice_canoe = get_user_meta($current_user->ID, 'mepr_first_year_of_ice_canoe', true);
$getPosition = get_user_meta($current_user->ID, 'position', true);
$captain = get_user_meta($current_user->ID, 'mepr_capitaine_de_lequipe', true);
$leader = get_user_meta($current_user->ID, 'mepr_responsable_de_lequipe', true);
$profileImage = get_field('profile_image', 'user_' . $current_user->ID);

$teams = [];
$args = array(
    'post_type' => 'teams',
    'posts_per_page' => -1,
    'post_status' => 'publish',
    'orderby' => 'title',
    'order' => 'ASC'
);
$teams_query = new WP_Query($args);
if ($teams_query->have_posts()) {
    while ($teams_query->have_posts()) {
        $teams_query->the_post();
        $teams[get_the_ID()] = get_the_title();
    }
}
wp_reset_postdata();
$getTeam = get_user_meta($current_user->ID, 'associate_team', true);

// trainings
$training_done = get_user_meta($current_user->ID, 'training_done', true);
?>

<div class="tab-content profile" id="my-profile">
    <div class="tabs">
        <ul class="flex">
            <?php
            foreach ($profileTabs as $tab => $title) {
                echo '<li class="' . $tab . '" data-tab="' . $tab . '">' . $title . '</li>';
            }
            ?>
        </ul>
        <script type="module">
            jQuery(function($) {
                // check params
                let params = getParams('tab');
                const availbale = ['information', 'subscription', 'payment'];
                if (!availbale.includes(params)) {
                    setParams('tab', 'information');
                    params = 'information';
                }

                $('.tabs ul li').removeClass('active');
                $('.tabs ul li.' + params).addClass('active');
                var tab_id = $('.tabs ul li.' + params).attr('data-tab');
                jQuery('.tabs').find('.personal-tab').removeClass('active');
                jQuery('#' + tab_id).addClass('active');
                $('.tab-area .tab-content[data-tab="' + params.tab + '"]').addClass('active');

                jQuery('.tabs ul li').click(function(e) {
                    e.preventDefault();
                    jQuery('.tabs ul li').removeClass('active');
                    jQuery(this).addClass('active');
                    var tab_id = jQuery(this).attr('data-tab');
                    jQuery('.tabs').find('.personal-tab').removeClass('active');
                    jQuery('#' + tab_id).addClass('active');
                    setParams('tab', tab_id);
                });
            });
        </script>
        <div id="information" class="personal-tab active">
            <div class="message"></div>
            <form method="POST" id="update-profile">
                <div class="form-option">
                    <label for="profile-image">
                        <img src="<?php echo $profileImage ? $profileImage : get_stylesheet_directory_uri() . '/assets/images/profile.png' ?>" height="70" width="50" alt="" class="rounded">
                    </label>
                    <input type="file" name="profile-image" id="profile-image">
                </div>

                <div class="first-name form-option">
                    <label for="first-name">First name</label>
                    <input type="text" name="first-name" id="first-name" value="<?php echo $current_user->user_firstname ?>" required />
                </div>

                <div class="last-name form-option">
                    <label for="last-name">Last name</label>
                    <input type="text" name="last-name" id="last-name" value="<?php echo $current_user->user_lastname ?>" required>
                </div>

                <div class="sex form-option">
                    <label for="sex">Sex</label>
                    <select name="sex" id="sex" required>
                        <option value="">Choose Gender</option>
                        <?php
                        foreach ($sexe as $sex => $label) { ?>
                            <option <?php echo $sex == $mepr_sexe ? "selected" : ""; ?> value=<?php echo $sex; ?>><?php echo $label; ?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="city form-option">
                    <label for="city">City</label>
                    <input type="text" name="city" id="city" value="<?php echo $city; ?>" required />
                </div>

                <div class="phone form-option">
                    <label for="phone">Phone</label>
                    <input type="tel" name="phone" id="phone" value="<?php echo $mepr_telephone; ?>" required />
                </div>

                <div class="ice-canoe form-option">
                    <label for="ice-canoe">First year of ice canoe</label>
                    <input type="number" name="ice-canoe" id="ice-canoe" value="<?php echo $ice_canoe; ?>" required />
                </div>

                <div class="position form-option">
                    <label for="position">Team</label>
                    <select name="position" id="position" required>
                        <option value="">Choose Team</option>
                        <?php
                        foreach ($teams as $team => $label) { ?>
                            <option <?php echo $team == $getTeam ? "selected" : ""; ?> value=<?php echo $team; ?>><?php echo $label; ?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="position form-option">
                    <label for="position">Position</label>
                    <select name="position" id="position" required>
                        <?php
                        foreach ($positions as $position => $label) { ?>
                            <option <?php echo $position == $getPosition ? "selected" : ""; ?> value=<?php echo $position; ?>><?php echo $label; ?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="mp-form-row mepr_custom_field mepr_mepr_responsable_de_lequipe">
                    <?php $checked = $leader ? 'checked="checked"' : ""; ?>
                    <label for="mepr_responsable_de_lequipe" class="mepr-checkbox-field mepr-form-input ">
                        <input type="checkbox" name="mepr_responsable_de_lequipe" id="mepr_responsable_de_lequipe" <?php echo $checked; ?>>
                        <?php echo _e('Leader', 'memberpress'); ?>
                    </label>
                </div>
                <div class="mp-form-row mepr_custom_field mepr_capitaine_de_lequipe">
                    <?php $checkedCaptain = $captain ? 'checked="checked"' : ""; ?>
                    <label for="mepr_capitaine_de_lequipe" class="mepr-checkbox-field mepr-form-input ">
                        <input type="checkbox" name="mepr_capitaine_de_lequipe" id="mepr_capitaine_de_lequipe" <?php echo $checkedCaptain; ?>>
                        <?php echo _e('Captain', 'memberpress'); ?>
                    </label>
                </div>

                <div class="mp-form-submit">
                    <input type="submit" class="mepr-submit" value="Save Changes">
                    <img src="http://localhost/greenplay/wp-admin/images/loading.gif" alt="Loading..." style="display: none;" class="mepr-loading-gif is-loading" title="Loading icon">
                </div>
            </form>

            <!-- trainings -->
            <div class="trainings">
                <?php
                if ($training_done) {
                    echo "You have done your training";
                } else {
                    echo "You did not do you theoric training. <br/>Contact us to find a date(link)";
                } ?>
            </div>
        </div>
        <?php
        include_once get_stylesheet_directory() . '/my-account/subscriptions.php';
        ?>

        <div id="payment" class="personal-tab">
            payment level tab content
        </div>
    </div>


    <script>
        function returnformValidations() {
            var title = document.getElementById("title").value;
            var content = document.getElementById("content").value;
            var category = document.getElementById("category").value;

            if (title == "") {
                alert("Please enter post title!");
                return false;
            }
            if (content == "") {
                alert("Please enter post content!");
                return false;
            }
            if (category == "") {
                alert("Please choose post category!");
                return false;
            }
        }
    </script>
</div>