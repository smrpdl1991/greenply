<?php
$args = array(
    'post_type' => 'memberpressproduct',
    'orderby' => 'meta_value_num post_date',
);

$getMemberShip = new WP_Query($args);
?>

<div id="subscription" class="personal-tab">
    <div class=" subscription-list">
        <?php
        // The Loop
        while ($getMemberShip->have_posts()) {
            $getMemberShip->the_post();
        ?>
            <div class="list flex  mb-10">
                <div class="title max-w-300">
                    <h3><?php the_title(); ?></h3>
                    <?php echo wpautop(get_the_content()); ?>
                </div>
                <div class="price">50$</div>
                <a href="<?php the_permalink(); ?>" class='btn btn-primary'>
                    Subscribe
                </a>
            </div>

        <?php
        }
        wp_reset_postdata();
        ?>
    </div>
</div>