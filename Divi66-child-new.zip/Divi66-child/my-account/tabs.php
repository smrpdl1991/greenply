<?php
$tabs = [
    'my-profile'       => 'My Profile',
    'my-team'          => 'My Team',
    'race-circuit'  => 'Race Circuit',
    'ice-cannoeing' => 'Ice Cannoeing',
    'resources'     => 'Resources'
];

$myAccount = 'my-account';

$getPermalink = get_home_url();

?>

<div class="account-tabs flex">
    <ul>
        <?php
        foreach ($tabs as $tab => $title) {
            $class = $activeTab && $tab === $activeTab ? 'active' : '';
            echo '<li class="' . $class . '"><a href="' . $getPermalink . '/' . $myAccount . '/' . $tab . '" >' . $title . '</a></li>';
        }
        ?>
    </ul>
</div>