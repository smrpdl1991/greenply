<?php
$current_user = wp_get_current_user();
$captain = get_user_meta($current_user->ID, 'mepr_capitaine_de_lequipe', true);
$leader = get_user_meta($current_user->ID, 'mepr_responsable_de_lequipe', true);
$associate_team = get_user_meta($current_user->ID, 'associate_team', true);
$teamName = get_the_title($associate_team); // get team name
$team_class = get_field('team_class', $associate_team);
$team_image = get_the_post_thumbnail_url($associate_team, 'full'); // get team image
$number_of_the_canoe = get_field('number_of_the_canoe', $associate_team);

$user_query = get_team_members($associate_team);

var_dump($team_class);

$teamCaptains = [];
$teamLeaders = [];
// loop through the users and get the captains
if (!empty($user_query)) {
    foreach ($user_query as $user) {
        $userCaptain = get_user_meta($user->ID, 'mepr_capitaine_de_lequipe', true);
        if ($userCaptain == 'on') {
            $teamCaptains[] = $user->user_firstname . ' ' . $user->user_lastname;
        }

        $userLeader = get_user_meta($user->ID, 'mepr_responsable_de_lequipe', true);
        if ($userLeader == 'on') {
            $teamLeaders[] = $user->user_firstname . ' ' . $user->user_lastname;
        }
    }
}

?>

<div class="team tab-content" id="my-team">
    <?php
    // If there is no team associated with this user
    if ($associate_team) { ?>
        <?php
        include get_stylesheet_directory() . '/my-account/teamForm.php'; ?>
        <div class="team-details">
            <!-- team name -->
            <div class="team-name">
                <h3>Name:</h3>
                <?php echo $teamName; ?>
            </div>
            <div class="team-class">
                <h3>Class:</h3>
                <?php echo $class ? $class['label']  : ""; ?>
            </div>
            <div class="team-canoe-number">
                <h3>Canoe number:</h3>
                <?php echo $number_of_the_canoe ?  $number_of_the_canoe : 0 ?>
            </div>
            <div class="team-captain">
                <h3>Team Captain:</h3>
                <?php
                // join array
                $teamCaptains = implode(', ', $teamCaptains);
                echo $teamCaptains;
                ?>
            </div>
            <div class="team-leader">
                <h3>Team leader:</h3>
                <?php
                // join array
                $teamLeaders = implode(', ', $teamLeaders);
                echo $teamLeaders;
                ?>
            </div>
            <div class="image">
                <?php
                $image = get_the_post_thumbnail($associate_team, 'full');
                if (!empty($image)) {
                    echo wp_get_attachment_image($image['id'], 'full');
                }
                ?>
            </div>

        </div>
        <div class="lists">
            <div class="team-list">
                <?php
                // list of Canoer according to the number of the canoe
                for ($i = 1; $i <= 10; $i++) {
                ?>
                    <div class="canoe-list flex">
                        <?php
                        echo '<h4>Canoe ' . $i . '</h4>';

                        if ($leader) { ?>
                            <div class="delete">
                                <span onclick="onTeamDelete(<?php echo $user->ID; ?>)">Delete <img src="<?php echo get_home_url(); ?>/wp-admin/images/loading.gif" alt="Loading..." style="display: none;" class="mepr-loading-gif is-loading" title="Loading icon"></span>
                            </div>
                    </div>
            <?php }
                    }
            ?>
            </div>
        </div>
    <?php
    } else {
    ?>
        <div class="no-team flex flex-col mb-10">
            <p class="mb-10">

                There is no team associated with your account
            </p>
            <!-- Dialog Trigger -->
            <button data-fancybox="dialog" data-src="#dialog-content" class="btn btn-primary">Create Team</button>

            <div id="dialog-content" style="display:none;max-width:500px;">
                <!-- When team leader click on “create a team”. It brings us to a form with these questions -->
                <?php
                include get_stylesheet_directory() . '/my-account/teamForm.php'; ?>
            </div>
        </div>
        <script type="module">
            // Show HTML element
            Fancybox.show([{
                src: "#dialog-content",
                type: "inline"
            }]);
        </script>
    <?php
    } ?>
    <div class="message"></div>

</div>