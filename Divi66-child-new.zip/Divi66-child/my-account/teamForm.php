<?php
$team_name = $teamName ? $teamName : "";
$canoe_number = $number_of_the_canoe ? $number_of_the_canoe : "";

$teamClasses = [
    'Elite open' => 'Elite open',
    'Elite femme' => 'Elite femme',
    'Elitemixte' => 'Elitemixte',
    'Sport' => 'Sport',
]

?>

<form id="create-team-form" enctype="multipart/form-data">
    <!-- Name of the team (need validation for duplicate)-->
    <div class="team-name form-option">
        <label for="team_name">Name of the team</label>
        <input type="text" name="team_name" placeholder="Enter your team name" id="team_name" value="<?php echo $team_name; ?>" required>
    </div>

    <div class="canoe-number form-option">
        <label for="canoe_number">Number of the canoe</label>
        <input type="number" name="canoe_number" placeholder="Number of the canoe" id="canoe_number" value="<?php echo $canoe_number; ?>" required>
    </div>

    <div class="class form-option">
        <label for="class">Class : (Elite open, Elite femme, Elitemixte and Sport)
        </label>
        <select name="team_class" id="class" required>
            <?php
            foreach ($teamClasses as $key => $value) {
                if ($team_class['value'] == $key) {
                    echo "<option value='$key' selected>$value</option>";
                } else {
                    echo "<option value='$key'>$value</option>";
                }
            } ?>
    </div>

    <div class="team-picture form-option">
        <img src="<?php echo $team_image ? $team_image : get_stylesheet_directory_uri() . '/assets/images/profile.png' ?>" height="70" width="50" alt="">
        <label for="team_picture">Picture of the team</label>
        <input type="file" number="team_picture" placeholder="Upload a picture" id="team_picture" required>
    </div>
    <input type="hidden" name="action" value="greenplay_create_team">
    <input type="hidden" name="team_id" value="<?php echo $associate_team; ?>">

    <div class="mp-form-submit">
        <input type="submit" class="mepr-submit submit" value="<?php echo $team_name ? 'Update Team' : 'Create Team'; ?>" />
        <img src=" <?php echo get_home_url(); ?>/wp-admin/images/loading.gif" alt="Loading..." style="display: none;" class="mepr-loading-gif is-loading" title="Loading icon">
    </div>
    <div class="message"></div>

</form>