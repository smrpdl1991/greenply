<?php
/*
 * Template Name: Account
 * Template Post Type: page
 */

get_header();

$tabs = [
    'my-profile'       => 'My Profile',
    'my-team'          => 'My Team',
    'race-circuit'  => 'Race Circuit',
    'ice-cannoeing' => 'Ice Cannoeing',
    'resources'     => 'Resources'
];

$get_team = get_field('team_members', '47335');

?>

<div id="main-content">
    <div class="container">
        <div id="content-area" class="clearfix">
            <h1 class="main_title"><?php the_title(); ?></h1>
            <div class="entry-content mb-10">
                <?php the_content(); ?>
            </div>

            <!-- tabs -->
            <div class="account-area">
                <div class="tabs flex">
                    <ul>
                        <?php
                        foreach ($tabs as $tab => $title) {
                            $class = $tab === 'my-profile' ? 'selected' : '';
                            echo '<li><a href="#' . $tab . '" class="' . $class . '">' . $title . '</a></li>';
                        }
                        ?>
                    </ul>

                    <?php
                    // profile
                    include_once 'my-account/profile.php';

                    // team
                    include_once 'my-account/team.php';
                    ?>
                </div>
            </div>
        </div>
    </div>

    <?php
    get_footer();
