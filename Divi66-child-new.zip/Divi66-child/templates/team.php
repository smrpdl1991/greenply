<?php
/*
 * Template Name: My Team
 * Template Post Type: page
 */

get_header();
?>

<div id="main-content">
    <div class="container">
        <div id="content-area" class="clearfix">
            <h1 class="main_title"><?php the_title(); ?></h1>
            <div class="entry-content mb-10">
                <?php the_content(); ?>
            </div>
        </div>
        <div class="account-area team-contente">

            <!-- tabs section here -->
            <?php
            // profile
            $activeTab = 'my-team';
            include_once get_stylesheet_directory() . '/my-account/tabs.php';
            ?>

            <!-- content here -->
            <div class="profile-area">
                <?php
                // profile
                include_once get_stylesheet_directory() . '/my-account/team.php';
                ?>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
